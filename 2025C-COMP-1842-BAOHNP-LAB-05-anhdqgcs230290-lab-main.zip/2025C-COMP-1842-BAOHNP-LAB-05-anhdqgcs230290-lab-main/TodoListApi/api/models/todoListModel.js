const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const taskSchema = new Schema({
    name: {
        type: String,
        required: ' kindly enter the name of the task',
    },
    created_date: {
        type: Date,
        default: Date.now,
    },
    status: {
        type: [{
            type: String,
            enum: ['pending', 'in progress', 'completed']
        }],
        default: 'pending',

    }


});
module.exports = mongoose.model('Tasks', taskSchema);