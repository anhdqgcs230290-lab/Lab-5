const express = require('express'),
    app = express(),
    port = process.env.PORT || 3001,
    mongoose = require('mongoose'),
    Task = require('./api/models/todoListModel'),
    bodyParser = require('body-parser');

mongoose.set('strictQuery', true);
mongoose.connect('mongodb://localhost/TodoListDB');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

const rountes = require('./api/routes/todoListRoutes');
rountes(app);

app.listen(port);
console.log('Todo List RESTful API server started on: ' + port);